<?php

//login.php

include('database_connection.php');

session_start();

if(isset($_SESSION["admin_id"]))
{
  header('location:index.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>JIM Student Attendance System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
  <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
  <section style="background-color:#75b3ff">
    <div class="forms23-block-hny">
      <div class="wrapper">
        <center><h1>JIM ERP | LOGIN</h1></center>
        <!--
          <a class="logo" href="index.html">
            <img src="logo.jpg" alt="Your logo" title="Your logo" style="height:100px;" />
          </a> 
        -->
        <div class="d-grid forms23-grids">
          <div class="form23">
            <div class="main-bg">
              <h6 class="sec-one">Admin</h6>
              <div class="speci-login first-look">
                <img src="images/user.png" alt="" class="img-responsive">
              </div>
            </div>
            <div class="bottom-content">
              <form method="post" id="admin_login_form">
              <input type="text" name="admin_user_name" id="admin_user_name" class="input-form" placeholder="Your Email" required="required"/>
              <span id="error_admin_user_name" class="text-danger"></span>
            
            
              <input type="password" name="admin_password" id="admin_password" class="input-form" placeholder="Your Password" required="required"/>
              <span id="error_admin_password" class="text-danger"></span>
              <button type="submit" name="admin_login" id="admin_login" class="loginhny-btn btn">Login</button>
              </form>
            </div>
          </div>
        </div>
        <div class="w3l-copy-right text-center">
          <p>© 2020 JIM ERP. All rights reserved | Design by Nitin Gupta
            <a href="http://jimkanpur.ac.in/" target="_blank">JIM|ERP</a></p>
        </div>
      </div>
    </div>
  </section>
</body>
</html>

<script>
$(document).ready(function(){
  $('#admin_login_form').on('submit', function(event){
    event.preventDefault();
    $.ajax({
      url:"check_admin_login.php",
      method:"POST",
      data:$(this).serialize(),
      dataType:"json",
      beforeSend:function(){
        $('#admin_login').val('Validate...');
        $('#admin_login').attr('disabled', 'disabled');
      },
      success:function(data)
      {
        if(data.success)
        {
          location.href = "<?php echo $base_url; ?>admin";
        }
        if(data.error)
        {
          $('#admin_login').val('Login');
          $('#admin_login').attr('disabled', false);
          if(data.error_admin_user_name != '')
          {
            $('#error_admin_user_name').text(data.error_admin_user_name);
          }
          else
          {
            $('#error_admin_user_name').text('');
          }
          if(data.error_admin_password != '')
          {
            $('#error_admin_password').text(data.error_admin_password);
          }
          else
          {
            $('#error_admin_password').text('');
          }
        }
      }
    });
  });
});
</script>