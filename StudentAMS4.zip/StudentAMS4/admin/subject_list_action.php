<?php
$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'attendance2');
$q="select * from tbl_subject_list";
$query = mysqli_query($con,$q);
if(mysqli_num_rows($query)>0){
	while($result = mysqli_fetch_array($query)){
	?>
	<tr>
		<td><?php echo $result['Subject_Code']?></td>
		<td><?php echo $result['Subject_Name']?></td>
		<td><?php echo $result['Subject_Course']?></td>
		
	</tr>
<?php
	}
}
?>
