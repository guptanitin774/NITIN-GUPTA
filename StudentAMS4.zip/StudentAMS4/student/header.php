<!DOCTYPE html>
<html lang="en">
<head>
  <title>JIM ERP | Online Attendance</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/dataTables.bootstrap4.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.dataTables.min.js"></script>
  <script src="js/dataTables.bootstrap4.min.js"></script>
</head>
<body>

<div class="jumbotron-small text-center" style="background-color:#cce6ff">
<br><img src="images/logo.jpg" style="height:80px">
  <h1>JIM ERP | Student Enrollement </h1>
  <br>
</div>